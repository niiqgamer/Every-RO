ALTER TABLE `mob_db`
	ADD COLUMN `racegroup_ep172alpha` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172beta` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172bath` tinyint(1) unsigned DEFAULT NULL
;
ALTER TABLE `mob_db2`
	ADD COLUMN `racegroup_ep172alpha` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172beta` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172bath` tinyint(1) unsigned DEFAULT NULL
;
ALTER TABLE `mob_db_re`
	ADD COLUMN `racegroup_ep172alpha` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172beta` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172bath` tinyint(1) unsigned DEFAULT NULL
;
ALTER TABLE `mob_db2_re`
	ADD COLUMN `racegroup_ep172alpha` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172beta` tinyint(1) unsigned DEFAULT NULL,
	ADD COLUMN `racegroup_ep172bath` tinyint(1) unsigned DEFAULT NULL
;
