DROP TABLE `ragsrvinfo`;
