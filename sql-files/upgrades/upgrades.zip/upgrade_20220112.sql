ALTER TABLE `char`
	ADD COLUMN `inventory_slots` smallint(6) NOT NULL default '100'
;
