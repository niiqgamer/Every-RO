ALTER TABLE `char`
	ADD COLUMN `last_instanceid` int(11) unsigned NOT NULL default '0' AFTER `last_y`
;
