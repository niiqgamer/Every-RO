ALTER TABLE `achievement`
	MODIFY `count1` int unsigned NOT NULL default '0',
	MODIFY `count2` int unsigned NOT NULL default '0',
	MODIFY `count3` int unsigned NOT NULL default '0',
	MODIFY `count4` int unsigned NOT NULL default '0',
	MODIFY `count5` int unsigned NOT NULL default '0',
	MODIFY `count6` int unsigned NOT NULL default '0',
	MODIFY `count7` int unsigned NOT NULL default '0',
	MODIFY `count8` int unsigned NOT NULL default '0',
	MODIFY `count9` int unsigned NOT NULL default '0',
	MODIFY `count10` int unsigned NOT NULL default '0';
