ALTER TABLE `item_db`
	MODIFY `name_english` varchar(100);
ALTER TABLE `item_db2`
	MODIFY `name_english` varchar(100);
ALTER TABLE `item_db_re`
	MODIFY `name_english` varchar(100);
ALTER TABLE `item_db2_re`
	MODIFY `name_english` varchar(100);
