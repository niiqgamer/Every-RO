ALTER TABLE `guild`
	CHANGE COLUMN `next_exp` `next_exp` bigint(20) unsigned NOT NULL default '0';
