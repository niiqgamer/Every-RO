ALTER TABLE `picklog`
	ADD COLUMN `enchantgrade` tinyint unsigned NOT NULL default '0'
;
