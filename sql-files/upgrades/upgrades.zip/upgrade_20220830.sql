ALTER TABLE `char`
	ADD COLUMN `body_direction` tinyint unsigned NOT NULL default '0'
;
