ALTER TABLE `acc_reg_num`
	MODIFY `value` bigint(11) NOT NULL default '0';

ALTER TABLE `global_acc_reg_num`
	MODIFY `value` bigint(11) NOT NULL default '0';

ALTER TABLE `char_reg_num`
	MODIFY `value` bigint(11) NOT NULL default '0';
