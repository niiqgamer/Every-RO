ALTER TABLE `guild_expulsion` ADD COLUMN `char_id` int(11) unsigned NOT NULL default '0';
