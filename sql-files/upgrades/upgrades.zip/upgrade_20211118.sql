ALTER TABLE `item_db_re`
	ADD COLUMN `class_fourth` tinyint unsigned DEFAULT NULL
;
ALTER TABLE `item_db2_re`
	ADD COLUMN `class_fourth` tinyint unsigned DEFAULT NULL
;
