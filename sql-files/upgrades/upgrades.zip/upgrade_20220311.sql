-- Reset the following quests to match official Rockridge quests
DELETE FROM `quest` WHERE `quest_id` = 1321;
DELETE FROM `quest` WHERE `quest_id` = 1322;
DELETE FROM `quest` WHERE `quest_id` = 1323;
DELETE FROM `quest` WHERE `quest_id` = 1324;
DELETE FROM `quest` WHERE `quest_id` = 1325;
DELETE FROM `quest` WHERE `quest_id` = 1326;
DELETE FROM `quest` WHERE `quest_id` = 1327;
DELETE FROM `quest` WHERE `quest_id` = 1328;
DELETE FROM `quest` WHERE `quest_id` = 1329;
DELETE FROM `quest` WHERE `quest_id` = 1330;
