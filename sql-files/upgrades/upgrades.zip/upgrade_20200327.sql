DROP TABLE `interreg`;
