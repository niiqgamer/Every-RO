ALTER TABLE `market`
MODIFY `amount` INT(11) NOT NULL
;
