ALTER TABLE `char`
	ADD COLUMN `disable_call` tinyint unsigned NOT NULL default '0'
;
